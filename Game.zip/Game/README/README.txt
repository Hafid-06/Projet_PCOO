- Auteur : EL JAGHAOUI Abdelhafid

- Lorsque vous êtes dans le dossier Game dans votre terminal :

	- Pour compiler et exécuter : make

	- Pour compiler seulement : make build

	- Pour exécuter seulement : make run
	
	- Pour nettoyer les fichier de build : make clean

- Lien Github : https://github.com/Hafid-06/Projet_PCOO

Description du jeu : Un jeu de plateforme en 2D développé avec libGDX, où le joueur contrôle un personnage pour combattre des ennemis (touche ESPACE) et récupérer des objets. 
Vous pouvez aussi voler afin de récupérer les boules de cristal qui sont en hauteur en appuyant plusieurs fois sur la touche UP.
Le but du jeu est de tuer tous les ennemis et récupérer toutes les boules de cristal contenu dans la carte sans vous faire tuer ou tomber de la carte. Une fois cela est fait, la partie est gagné (une fois
que vous avez atteint le score de 15).
