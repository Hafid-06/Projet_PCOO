package com.game.sprites.tileObjects;

import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTile;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.*;
import com.game.Main;
import com.game.screens.GameScreen;

public abstract class InteractiveTileObject {

    // Propriétés de l'objet interactif
    protected World world;  // Monde physique de Box2D
    protected TiledMap map;  // Carte Tiled
    protected TiledMapTile tile;  // Tuile de la carte
    protected Rectangle bounds;  // Limites de l'objet interactif
    protected Body body;  // Corps physique associé à l'objet interactif
    protected Fixture fixture;  // Fixture (collisions) associée au corps
    protected MapObject object;  // L'objet dans la carte
    protected GameScreen screen;  // L'écran de jeu

    /**
     * Constructeur de la classe InteractiveTileObject.
     * Initialise le corps physique et la fixture de l'objet interactif.
     *
     * @param screen L'écran de jeu auquel l'objet interactif appartient
     * @param object L'objet de la carte Tiled représentant cet objet interactif
     */
    public InteractiveTileObject(GameScreen screen, MapObject object) {
        if (screen == null) {
            throw new IllegalArgumentException("GameScreen cannot be null");
        }
        if (object == null) {
            throw new IllegalArgumentException("MapObject cannot be null");
        }

        this.world = screen.getWorld();
        this.map = screen.getMap();
        this.bounds = ((RectangleMapObject) object).getRectangle();  // Récupère les limites de l'objet
        this.object = object;
        this.screen = screen;

        // Définition du corps physique de l'objet
        BodyDef bdef = new BodyDef();
        FixtureDef fdef = new FixtureDef();
        PolygonShape shape = new PolygonShape();

        // Le corps est statique (il ne bouge pas)
        bdef.type = BodyDef.BodyType.StaticBody;
        bdef.position.set((bounds.getX() + bounds.getWidth() / 2) / Main.PPM, (bounds.getY() + bounds.getHeight() / 2) / Main.PPM);  // Position du corps

        body = world.createBody(bdef);  // Création du corps dans le monde Box2D

        // Définition de la forme de l'objet (ici une boîte)
        shape.setAsBox(bounds.getWidth() / 2 / Main.PPM, bounds.getHeight() / 2 / Main.PPM);  // La forme prend la moitié des dimensions de l'objet
        fdef.shape = shape;
        fixture = body.createFixture(fdef);  // Création de la fixture et ajout au corps
    }

    /**
     * Méthode abstraite pour la collecte de boule de cristal (ou autre interaction spécifique).
     * Doit être implémentée par les classes filles.
     */
    public abstract void crystalBallCollect();

    /**
     * Définit un filtre de catégorie pour l'objet interactif (utilisé pour gérer les collisions).
     *
     * @param filterBit Le filtre de catégorie à appliquer à la fixture
     */
    public void setCategoryFilter(short filterBit) {
        if (fixture == null) {
            throw new IllegalStateException("Fixture is not initialized");
        }

        Filter filter = new Filter();
        filter.categoryBits = filterBit;  // Définir la catégorie de l'objet
        fixture.setFilterData(filter);  // Applique le filtre à la fixture
    }

    /**
     * Récupère la cellule de la carte Tiled à la position de l'objet interactif.
     *
     * @return La cellule correspondant à la position de l'objet
     */
    public TiledMapTileLayer.Cell getCell() {
        // Récupère la couche de tuiles
        TiledMapTileLayer layer = (TiledMapTileLayer) map.getLayers().get(2);
        // Convertit la position physique du corps en coordonnées de la carte Tiled et retourne la cellule correspondante
        return layer.getCell((int)(body.getPosition().x * Main.PPM / 16), (int)(body.getPosition().y * Main.PPM / 16)); // mes tiles font 16 * 16 pixels
    }
}
