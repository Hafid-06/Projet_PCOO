package com.game.sprites.player;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.*;
import com.game.Main;
import com.game.screens.GameScreen;
import com.badlogic.gdx.utils.Array;
import com.game.scenes.GameInfo;

public class Player extends Sprite {

    // Enumération des états possibles du joueur
    public enum State { FALLING, JUMPING, STANDING, RUNNING, ATTACKING, DEAD }

    // Variables d'état du joueur
    public State currentState;
    public State previousState;

    public World world;
    public Body b2body;

    // Variables de texture et d'animation du joueur
    private TextureRegion playerStand;
    private Animation<TextureRegion> playerDead;
    private Animation<TextureRegion> playerRun;
    private Animation<TextureRegion> playerJump;
    private Animation<TextureRegion> playerAttack;

    private float stateTimer;
    private boolean runningRight;
    public boolean isAttacking;
    private boolean playerIsDead;
    private int lives;

    /**
     * Constructeur de la classe Player.
     * Initialise le joueur dans le monde physique.
     *
     * @param screen L'écran de jeu auquel le joueur appartient
     */
    public Player(GameScreen screen) {
        super(screen.getAtlas().findRegion("goku"));
        this.world = screen.getWorld();
        currentState = State.STANDING;
        previousState = State.STANDING;
        stateTimer = 0;
        lives = Main.LIVE;
        runningRight = true;
        isAttacking = false;
        playerIsDead = false;

        // Animation de course
        Array<TextureRegion> frames = new Array<>();
        for (int i = 2; i < 3; i++) {
            frames.add(new TextureRegion(getTexture(), i * 130, 300, 140, 121));
        }
        playerRun = new Animation<>(0.1f, frames);
        frames.clear();

        // Animation de saut
        for (int i = 0; i < 8; i++) {
            frames.add(new TextureRegion(getTexture(), i * 106, 416, 106, 165));
        }
        playerJump = new Animation<>(0.1f, frames);
        frames.clear();

        // Animation d'attaque
        for (int i = 0; i < 6; i++) {
            frames.add(new TextureRegion(getTexture(), i * 125, 590, 118, 150));
        }
        playerAttack = new Animation<>(0.2f, frames);
        frames.clear();

        // Animation de mort
        for (int i = 0; i < 1; i++) {
            frames.add(new TextureRegion(getTexture(), i * 150, 750, 150, 150));
        }
        playerDead = new Animation<>(0.1f, frames);
        frames.clear();

        definePlayer();
        playerStand = new TextureRegion(getTexture(), 0, 300, 109, 116);
        setBounds(0, 0, 50 / Main.PPM, 50 / Main.PPM); //(25)
        setRegion(playerStand);
    }

    /**
     * Mise à jour de l'état du joueur et de son animation.
     *
     * @param dt Delta time (temps écoulé depuis la dernière mise à jour)
     */
    public void update(float dt) {
        stateTimer += dt;
        if (playerIsDead) {
            if (currentState != State.DEAD) {
                currentState = State.DEAD;
                stateTimer = 0;
                // Arrête tous les mouvements physiques du joueur
                b2body.setLinearVelocity(0, 0);
                b2body.setAngularVelocity(0);
            }
            // Fixe la position du joueur pour éviter les effets de forces résiduelles
            b2body.setLinearVelocity(0, 0);
        }
        else {
            // Si le joueur est en vie, continue à mettre à jour sa position
            setPosition(b2body.getPosition().x - getWidth() / 2, b2body.getPosition().y - getHeight() / 2);
        }

        // Met à jour le sprite du joueur selon son état
        setRegion(getFrame(dt));
    }

    /**
     * Récupère le cadre de l'animation en fonction de l'état actuel du joueur.
     *
     * @param dt Delta time (temps écoulé depuis la dernière mise à jour)
     * @return Le cadre de l'animation à afficher
     */
    public TextureRegion getFrame(float dt) {
        currentState = getState();
        TextureRegion region;

        // Choisit l'animation en fonction de l'état du joueur
        switch (currentState) {
            case ATTACKING:
                region = playerAttack.getKeyFrame(stateTimer, false);
                if (playerAttack.isAnimationFinished(stateTimer)) {
                    isAttacking = false; // Fin de l'animation d'attaque
                }
                break;
            case JUMPING:
                region = playerJump.getKeyFrame(stateTimer, false);
                break;
            case RUNNING:
                region = playerRun.getKeyFrame(stateTimer, true);
                break;
            case DEAD:
                region = playerDead.getKeyFrame(stateTimer, false);
                break;
            case FALLING:
            case STANDING:
            default:
                region = playerStand;
                break;
        }

        // Gère la direction du sprite (flip horizontal si nécessaire)
        if ((b2body.getLinearVelocity().x < 0 || !runningRight) && !region.isFlipX()) {
            region.flip(true, false);
            runningRight = false;
        }
        else if ((b2body.getLinearVelocity().x > 0 || runningRight) && region.isFlipX()) {
            region.flip(true, false);
            runningRight = true;
        }

        // Réinitialise le timer de l'animation si l'état a changé
        stateTimer = currentState == previousState ? stateTimer + dt : 0;
        previousState = currentState;
        return region;
    }

    /**
     * Détermine l'état actuel du joueur en fonction de sa vitesse et de ses actions.
     *
     * @return L'état actuel du joueur
     */
    public State getState() {
        if (isAttacking) {
            return State.ATTACKING;
        } else if (b2body.getLinearVelocity().y > 0 || b2body.getLinearVelocity().y < 0 && previousState == State.JUMPING) {
            return State.JUMPING;
        } else if (b2body.getLinearVelocity().y < 0) {
            return State.FALLING;
        } else if (b2body.getLinearVelocity().x != 0) {
            return State.RUNNING;
        } else if (playerIsDead) {
            return State.DEAD;
        } else {
            return State.STANDING;
        }
    }

    /**
     * Définit le corps physique du joueur.
     * Initialise la fixture (collisions) et associe le joueur au corps physique.
     */
    public void definePlayer() {
        BodyDef bdef = new BodyDef();
        bdef.position.set(32 / Main.PPM, 32 / Main.PPM); // Position initiale du joueur
        bdef.type = BodyDef.BodyType.DynamicBody;
        b2body = world.createBody(bdef);

        // Définition de la fixture du joueur (forme circulaire pour les collisions)
        FixtureDef fdef = new FixtureDef();
        CircleShape shape = new CircleShape();
        shape.setRadius(6 / Main.PPM);
        fdef.filter.categoryBits = Main.PLAYER_BIT;
        fdef.filter.maskBits = Main.DEFAULT_BIT | Main.BALL_BIT | Main.ENEMY_BIT | Main.OBJECT_BIT | Main.WALL_BIT;
        fdef.shape = shape;
        Fixture mainFixture = b2body.createFixture(fdef);
        mainFixture.setUserData(this);

        // Libère la ressource de la forme géométrique après utilisation
        shape.dispose();
    }

    /**
     * Vérifie si le joueur est mort.
     *
     * @return True si le joueur est mort, false sinon
     */
    public boolean isDead() {
        return playerIsDead;
    }

    /**
     * Méthode appelée lorsque le joueur meurt.
     */
    public void die() {
        playerIsDead = true;
        System.out.println("You are dead !");
    }

    /**
     * Méthode appelée lorsque le joueur attaque.
     */
    public void attack() {
        isAttacking = true;
        stateTimer = 0; // Réinitialise le timer de l'animation d'attaque
    }

    /**
     * Vérifie si le joueur est hors des limites de la carte (tombe en dehors de la carte).
     *
     * @return True si le joueur est hors des limites, false sinon
     */
    public boolean isOutOfBounds() {
        return b2body.getPosition().y < -1;
    }

    /**
     * Vérifie si le joueur est en train d'attaquer.
     *
     * @return True si le joueur attaque, false sinon
     */
    public boolean isAttacking() {
        return this.isAttacking;
    }

    /**
     * Réduit le nombre de vies du joueur lorsqu'il touche un ennemi.
     */
    public void loseLife() {
        if (lives > 0) {
            lives--;
            GameInfo.loseLife();
            System.out.println("Vous avez été touché par un ennemie ! Vie(s) restante(s) : " + lives + ".");
            if (lives == 0) {
                die();
            }
        }
    }

    /**
     * Récupère le nombre actuel de vies du joueur.
     *
     * @return Le nombre de vies restantes
     */
    public int getLives() {
        return lives;
    }

    /**
     * Récupère le timer actuel de l'animation du joueur.
     *
     * @return Le timer d'état actuel
     */
    public float getStateTimer() {
        return stateTimer;
    }
}
