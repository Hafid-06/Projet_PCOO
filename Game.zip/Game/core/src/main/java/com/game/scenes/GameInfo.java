package com.game.scenes;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.Disposable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.game.Main;
import com.game.screens.GameScreen;

public class GameInfo implements Disposable {

    // Stage et viewport pour l'interface utilisateur
    public Stage stage;
    private Viewport viewport;

    // Chronomètre de jeu
    private Integer worldTimer; // Temps restant
    private float timeCount;    // Compteur pour les mises à jour de la minuterie
    private static boolean timeUp; // Indique si le temps est écoulé

    // Score et vies du joueur
    private static Integer score;   // Score du joueur
    private static short lives;     // Nombre de vies

    // Éléments d'affichage (Labels)
    private Label countdownLabel;   // Affichage du temps
    private static Label scoreLabel;// Affichage du score
    private Label timeLabel;        // Libellé "TIME"
    private Label levelLabel;       // Libellé du niveau
    private Label worldLabel;       // Libellé "WORLD"
    private Label CharacterLabel;   // Libellé du personnage
    private static Label livesLabel;// Affichage des vies


    /**
     * Constructeur de la classe GameInfo.
     * Initialise le stage, les vies, le score et les éléments d'interface utilisateur.
     *
     * @param sb SpriteBatch utilisé pour le rendu.
     */
    public GameInfo(SpriteBatch sb) {
        if (sb == null) {
            throw new IllegalArgumentException("SpriteBatch cannot be null");
        }

        // Initialisation des variables
        worldTimer = Main.worldTimer; // Durée initiale du jeu
        timeCount = 0;    // Compteur de temps
        score = 0;        // Score initial
        lives = Main.LIVE; // Nombre de vies défini dans la classe principale

        // Configuration du viewport et du stage
        viewport = new FitViewport(Main.V_WIDTH, Main.V_HEIGHT, new OrthographicCamera());
        stage = new Stage(viewport, sb);

        // Table pour organiser l'interface utilisateur
        Table table = new Table();
        table.top(); // Place les éléments en haut de l'écran
        table.setFillParent(true); // Remplit tout l'écran

        // Initialisation des labels
        countdownLabel = new Label(String.format("%03d", worldTimer), new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        countdownLabel.getStyle().font.getData().setScale(2);
        scoreLabel = new Label(String.format("%03d", score), new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        scoreLabel.getStyle().font.getData().setScale(2);
        timeLabel = new Label("TIME", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        timeLabel.getStyle().font.getData().setScale(2);
        levelLabel = new Label("LEVEL " + GameScreen.getCurrentLevel(), new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        levelLabel.getStyle().font.getData().setScale(2);
        worldLabel = new Label("WORLD", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        worldLabel.getStyle().font.getData().setScale(2);
        CharacterLabel = new Label("SCORE", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        CharacterLabel.getStyle().font.getData().setScale(2);
        livesLabel = new Label("LIVES : " + lives, new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        livesLabel.getStyle().font.getData().setScale(2);


        // Organisation des labels dans la table
        table.add(livesLabel).expandX().padTop(10);
        table.add(CharacterLabel).expandX().padTop(10);
        table.add(worldLabel).expandX().padTop(10);
        table.add(timeLabel).expandX().padTop(10);
        table.row();
        table.add().expandX();
        table.add(scoreLabel).expandX();
        table.add(levelLabel).expandX();
        table.add(countdownLabel).expandX();

        // Ajout de la table au stage
        stage.addActor(table);
    }

    /**
     * Met à jour le chronomètre et vérifie si le temps est écoulé.
     *
     * @param dt Temps écoulé depuis la dernière mise à jour (en secondes).
     */
    public void update(float dt) {
        if (dt < 0) {
            throw new IllegalArgumentException("Delta time cannot be negative");
        }

        timeCount += dt;
        if (timeCount >= 1) { // Mise à jour chaque seconde
            if (worldTimer > 0) {
                worldTimer--; // Décrémente le temps
            } else {
                timeUp = true; // Marque la fin du temps
                System.out.println("Temps écoulé...");
            }
            countdownLabel.setText(String.format("%03d", worldTimer)); // Met à jour l'affichage
            timeCount = 0; // Réinitialise le compteur
        }
    }

    /**
     * Réinitialise le chronomètre.
     */
    public void resetTimer() {
        worldTimer = Main.worldTimer; // Réinitialise le timer
        timeUp = false; // Réinitialise l'état de "temps écoulé"
        countdownLabel.setText(String.format("%03d", worldTimer)); // Met à jour l'affichage
    }


    /**
     * Décrémente le nombre de vies du joueur et met à jour l'affichage.
     */
    public static void loseLife() {
        if (lives <= 0) {
            throw new IllegalStateException("Cannot lose life when no lives are left");
        }

        if (lives > 0) {
            lives--; // Réduit le nombre de vies
            livesLabel.setText("LIVES : " + lives); // Met à jour le label des vies
        }
    }

    /**
     * Ajoute un score au total et met à jour l'affichage.
     *
     * @param value Points à ajouter au score.
     */
    public static void addScore(int value) {
        if (value < 0) {
            throw new IllegalArgumentException("Score value cannot be negative");
        }

        score += value; // Ajoute les points au score
        scoreLabel.setText(String.format("%03d", score)); // Met à jour le label du score
    }

    /**
     * Vérifie si le temps est écoulé.
     *
     * @return true si le temps est écoulé, false sinon.
     */
    public static boolean isTimeUp() {
        return timeUp;
    }

    /**
     * Récupère le score actuel du joueur.
     *
     * @return Le score du joueur.
     */
    public static Integer getScore() {
        return score;
    }

    /**
     * Libère les ressources utilisées par la classe.
     */
    @Override
    public void dispose() {
        stage.dispose();
    }
}
