package com.game.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.game.Main;

public class GameOverScreen implements Screen {
    private Viewport viewport;    // Vue de l'écran
    private Stage stage;          // Stage pour gérer les éléments à afficher
    private Game game;            // Référence au jeu principal

    /**
     * Constructeur de l'écran "Game Over".
     *
     * @param game Référence au jeu principal pour changer d'écran.
     */
    public GameOverScreen(Game game) {
        this.game = game;

        // Initialisation du viewport et du stage pour l'affichage
        viewport = new FitViewport(Main.V_WIDTH, Main.V_HEIGHT, new OrthographicCamera());
        stage = new Stage(viewport, ((Main) game).batch); // Utilisation du SpriteBatch du jeu principal

        // Création du style de texte pour les labels
        Label.LabelStyle font = new Label.LabelStyle(new BitmapFont(), Color.WHITE);

        // Création et configuration de la table pour organiser l'UI
        Table table = new Table();
        table.center(); // Centre les éléments dans la table
        table.setFillParent(true); // Fait en sorte que la table remplisse toute l'écran

        // Création des labels à afficher
        Label gameOverLabel = new Label("GAME OVER", font);
        gameOverLabel.getStyle().font.getData().setScale(2);
        Label playAgainLabel = new Label("Press Enter to Play Again", font);
        playAgainLabel.getStyle().font.getData().setScale(2);

        System.out.println("Dommage... Vous rejouez ?");

        // Ajout des labels à la table
        table.add(gameOverLabel).expandX();  // Étiquette de "Game Over"
        table.row();                         // Nouvelle ligne
        table.add(playAgainLabel).expandX().padTop(10f);  // Étiquette pour recommencer le jeu

        // Ajout de la table au stage
        stage.addActor(table);
    }

    @Override
    public void show() {
    }

    /**
     * Méthode de rendu qui gère l'affichage et les interactions.
     * Permet de détecter le clic de l'utilisateur pour recommencer le jeu.
     *
     * @param delta Temps écoulé depuis le dernier rendu
     */
    @Override
    public void render(float delta) {
        // Si l'utilisateur touche l'écran, on change d'écran pour recommencer le jeu
        if (Gdx.input.isKeyPressed(Input.Keys.ENTER)) {
            game.setScreen(new GameScreen((Main) game));  // Passe à l'écran du jeu
            dispose();  // Libère les ressources de cet écran
        }

        // Nettoyage de l'écran avec une couleur de fond noire
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Dessine tous les éléments du stage (ici, les labels dans la table)
        stage.draw();
    }

    /**
     * Méthode pour redimensionner l'écran (inutile ici, mais nécessaire pour l'interface Screen).
     *
     * @param width Nouvelle largeur de l'écran
     * @param height Nouvelle hauteur de l'écran
     */
    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    /**
     * Libère les ressources utilisées par cet écran (comme les textures, les stages, etc.).
     */
    @Override
    public void dispose() {
        stage.dispose();  // Libère les ressources associées au stage
    }
}
