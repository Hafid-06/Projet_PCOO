package com.game.tools;

import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.utils.Array;
import com.game.Main;
import com.game.screens.GameScreen;
import com.game.sprites.enemies.Cell;
import com.game.sprites.tileObjects.CrystalBall;
import com.game.sprites.enemies.Enemy;
import com.game.sprites.enemies.Frieza;

public class B2WorldCreator {

    // Listes pour stocker les ennemis et objets créés à partir de la carte
    private Array<Frieza> frieza;
    private Array<Cell> cell;

    /**
     * Constructeur de B2WorldCreator pour initialiser tous les objets physiques dans le monde de jeu.
     *
     * @param screen L'écran de jeu auquel appartient le créateur
     */
    public B2WorldCreator(GameScreen screen) {
        World world = screen.getWorld();
        TiledMap map = screen.getMap();
        BodyDef bdef = new BodyDef();
        PolygonShape shape = new PolygonShape();
        FixtureDef fdef = new FixtureDef();
        Body body;

        // Création des corps et fixtures pour le sol
        createGroundBodies(map, world, bdef, shape, fdef);

        // Création des corps et fixtures pour les murs
        createWallBodies(map, world, bdef, shape, fdef);

        // Création des objets boule de cristal
        createCrystalBallBodies(map, screen);

        // Création de tous les ennemis Friezas
        createFrieza(map, screen);

        // Création de tous les ennemis Cell
        createCell(map, screen);
    }

    /**
     * Crée les corps physiques du sol à partir de la carte.
     *
     * @param map La carte à partir de laquelle on crée les objets
     * @param world Le monde physique dans lequel les objets sont ajoutés
     * @param bdef Définit la configuration du corps
     * @param shape Décrit la forme du corps
     * @param fdef Définit les propriétés physiques du corps
     */
    private void createGroundBodies(TiledMap map, World world, BodyDef bdef, PolygonShape shape, FixtureDef fdef) {
        for (MapObject object : map.getLayers().get(3).getObjects().getByType(RectangleMapObject.class)) {
            Rectangle rect = ((RectangleMapObject) object).getRectangle();

            bdef.type = BodyDef.BodyType.StaticBody;
            bdef.position.set((rect.getX() + rect.getWidth() / 2) / Main.PPM, (rect.getY() + rect.getHeight() / 2) / Main.PPM);
            Body body = world.createBody(bdef);

            shape.setAsBox(rect.getWidth() / 2 / Main.PPM, rect.getHeight() / 2 / Main.PPM);
            fdef.shape = shape;
            body.createFixture(fdef);
        }
    }

    /**
     * Crée les corps physiques pour les murs à partir de la carte.
     *
     * @param map La carte à partir de laquelle on crée les objets
     * @param world Le monde physique dans lequel les objets sont ajoutés
     * @param bdef Définit la configuration du corps
     * @param shape Décrit la forme du corps
     * @param fdef Définit les propriétés physiques du corps
     */
    private void createWallBodies(TiledMap map, World world, BodyDef bdef, PolygonShape shape, FixtureDef fdef) {
        for (MapObject object : map.getLayers().get(5).getObjects().getByType(RectangleMapObject.class)) {
            Rectangle rect = ((RectangleMapObject) object).getRectangle();

            bdef.type = BodyDef.BodyType.StaticBody;
            bdef.position.set((rect.getX() + rect.getWidth() / 2) / Main.PPM, (rect.getY() + rect.getHeight() / 2) / Main.PPM);
            Body body = world.createBody(bdef);

            shape.setAsBox(rect.getWidth() / 2 / Main.PPM, rect.getHeight() / 2 / Main.PPM);
            fdef.shape = shape;
            fdef.filter.categoryBits = Main.WALL_BIT;
            body.createFixture(fdef);
        }
    }

    /**
     * Crée les corps physiques pour les boules de cristal à partir de la carte.
     *
     * @param map La carte à partir de laquelle on crée les objets
     * @param screen L'écran de jeu auquel appartient le créateur
     */
    private void createCrystalBallBodies(TiledMap map, GameScreen screen) {
        for (MapObject object : map.getLayers().get(4).getObjects().getByType(RectangleMapObject.class)) {
            new CrystalBall(screen, object);
        }
    }

    /**
     * Crée tous les objets Frieza à partir de la carte.
     *
     * @param map La carte à partir de laquelle on crée les objets
     * @param screen L'écran de jeu auquel appartient le créateur
     */
    private void createFrieza(TiledMap map, GameScreen screen) {
        frieza = new Array<Frieza>();
        for (MapObject object : map.getLayers().get(6).getObjects().getByType(RectangleMapObject.class)) {
            Rectangle rect = ((RectangleMapObject) object).getRectangle();
            frieza.add(new Frieza(screen, rect.getX() / Main.PPM, rect.getY() / Main.PPM));
        }
    }

    /**
     * Crée tous les objets Cell à partir de la carte.
     *
     * @param map La carte à partir de laquelle on crée les objets
     * @param screen L'écran de jeu auquel appartient le créateur
     */
    private void createCell(TiledMap map, GameScreen screen) {
        cell = new Array<Cell>();
        for (MapObject object : map.getLayers().get(7).getObjects().getByType(RectangleMapObject.class)) {
            Rectangle rect = ((RectangleMapObject) object).getRectangle();
            cell.add(new Cell(screen, rect.getX() / Main.PPM, rect.getY() / Main.PPM));
        }
    }

    /**
     * Récupère tous les Friezas créés dans le monde.
     *
     * @return La liste des Friezas
     */
    public Array<Frieza> getFrieza() {
        return frieza;
    }

    /**
     * Récupère toutes les Cell créées dans le monde.
     *
     * @return La liste des Cell
     */
    public Array<Cell> getCell() {
        return cell;
    }

    /**
     * Récupère tous les ennemis (Friezas et Cell) créés dans le monde.
     *
     * @return La liste des ennemis
     */
    public Array<Enemy> getEnemies() {
        Array<Enemy> enemies = new Array<Enemy>();
        enemies.addAll(frieza);
        enemies.addAll(cell);
        return enemies;
    }
}
