package com.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.game.Main;
import com.game.scenes.GameInfo;
import com.game.singleton.AudioManager;
import com.game.sprites.enemies.Enemy;
import com.game.sprites.player.Player;
import com.game.tools.B2WorldCreator;
import com.game.tools.WorldContactListener;

public class GameScreen implements Screen {

    private Main game;  // Référence au jeu principal
    private TextureAtlas atlas;  // Atlas pour les textures
    private OrthographicCamera camera;  // Caméra orthographique pour le rendu
    private SpriteBatch batch;  // SpriteBatch pour dessiner les sprites
    private GameInfo gameInfo;  // Infos de jeu (score, timer, etc.)
    private TiledMap map;  // Carte du niveau
    private OrthogonalTiledMapRenderer mapRenderer;  // Rendu de la carte
    private World world;  // Monde physique du jeu
    private Box2DDebugRenderer b2dr;  // Débogueur de Box2D pour afficher les corps physiques
    private Player player;  // Le joueur
    private Viewport gamePort;  // Vue du jeu
    private TmxMapLoader mapLoader;  // Chargeur de la carte
    private OrthogonalTiledMapRenderer renderer;  // Rendu de la carte
    private Music music;  // Musique de fond
    private Sound attackSound;  // Effet sonore pour l'attaque
    private B2WorldCreator creator;  // Créateur du monde et des objets (ennemis, etc.)
    private static int currentLevel = 1; // Niveau actuel



    /**
     * Constructeur de l'écran de jeu.
     * Initialise les éléments principaux du jeu.
     */
    public GameScreen(Main game) {
        atlas = new TextureAtlas("Tiles/goku&enemies.pack");
        this.game = game;
        camera = new OrthographicCamera();
        gamePort = new FitViewport(Main.V_WIDTH / Main.PPM, Main.V_HEIGHT / Main.PPM, camera);
        gameInfo = new GameInfo(game.batch);

        // Initialisation de la carte
        mapLoader = new TmxMapLoader();
        map = mapLoader.load("Maps/level" + currentLevel + ".tmx");
        renderer = new OrthogonalTiledMapRenderer(map, 1 / Main.PPM);
        camera.position.set(gamePort.getScreenWidth() / 2, gamePort.getScreenHeight() / 2, 0);

        // Initialisation du monde physique
        world = new World(new Vector2(0, -10), true);
        b2dr = new Box2DDebugRenderer();
        player = new Player(this);

        world.setContactListener(new WorldContactListener());

        music = AudioManager.getInstance().getBackgroundMusic();
        AudioManager.getInstance().playBackgroundMusic();

        attackSound = AudioManager.getInstance().getAttackSound();

        creator = new B2WorldCreator(this);

        // Réinitialisation du timer
        gameInfo.resetTimer();
    }

    /**
     * Méthode de gestion des entrées utilisateur (mouvements et actions).
     *
     * @param dt Temps écoulé depuis le dernier rendu.
     */
    public void handleInput(float dt) {
        if (player.currentState != Player.State.DEAD) {
            if (Gdx.input.isKeyJustPressed(Input.Keys.UP)) {
                player.b2body.applyLinearImpulse(new Vector2(0, 4f), player.b2body.getWorldCenter(), true);
            }
            if (Gdx.input.isKeyPressed(Input.Keys.RIGHT) && player.b2body.getLinearVelocity().x <= 2) {
                player.b2body.applyLinearImpulse(new Vector2(0.1f, 0), player.b2body.getWorldCenter(), true);
            }
            if (Gdx.input.isKeyPressed(Input.Keys.LEFT) && player.b2body.getLinearVelocity().x >= -2) {
                player.b2body.applyLinearImpulse(new Vector2(-0.1f, 0), player.b2body.getWorldCenter(), true);
            }
            if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
                player.attack();
                attackSound.play();
            }
        }
    }


    /**
     * Mise à jour du jeu : gestion des entrées, mise à jour du monde physique et des personnages.
     *
     * @param dt Temps écoulé depuis le dernier rendu.
     */
    public void update(float dt) {
        handleInput(dt);
        world.step(1 / 60f, 6, 2);  // Mise à jour du monde physique (Box2D)
        player.update(dt);
        for (Enemy enemy : creator.getEnemies()) {
            enemy.update(dt);
        }
        gameInfo.update(dt);
        camera.position.x = player.b2body.getPosition().x;
        camera.update();
        renderer.setView(camera);
    }

    public TextureAtlas getAtlas() {
        return atlas;
    }

    @Override
    public void show() {
    }

    /**
     * Méthode de rendu de l'écran de jeu.
     *
     * @param delta Temps écoulé depuis le dernier rendu.
     */
    @Override
    public void render(float delta) {
        update(delta);

        Gdx.gl.glClearColor(0, 0, 0, 1);  // Nettoyage de l'écran avec un fond noir
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        renderer.render();  // Rendu de la carte
        b2dr.render(world, camera.combined);  // Rendu des objets Box2D (débogage)
        game.batch.setProjectionMatrix(camera.combined);  // Projection du batch avec la caméra
        game.batch.begin();
        player.draw(game.batch);  // Dessin du joueur
        for (Enemy enemy : creator.getEnemies()) {
            enemy.draw(game.batch);  // Dessin des ennemis
        }
        game.batch.end();

        game.batch.setProjectionMatrix(gameInfo.stage.getCamera().combined);
        gameInfo.stage.draw();  // Affichage des informations du jeu (score, timer, etc.)

        // Vérification de la fin du jeu
        if (gameOver()) {
            game.setScreen(new GameOverScreen(game));  // Changement d'écran vers "Game Over"
            dispose();
        }

        // Vérification si le niveau a été accompli
        if (gameWon()) {
            System.out.println("Félicitations, vous avez réussi le niveau " + currentLevel + " !");
            game.setScreen(new GameWonScreen(game));  // Changement d'écran vers "Game Won"
            dispose();
        }
    }


    /**
     * Vérifie si le joueur a perdu.
     *
     * @return True si le joueur est mort ou le temps est écoulé ou il tombe en dehors de la map.
     */
        public boolean gameOver() {
            return (player.currentState == Player.State.DEAD || GameInfo.isTimeUp() || player.isOutOfBounds()) && player.getStateTimer() > 2;
        }

    /**
     * Vérifie si le joueur a gagné.
     *
     * @return True si le joueur a gagne le niveau.
     */
    public boolean gameWon() {
        return (player.currentState != Player.State.DEAD && !GameInfo.isTimeUp() && GameInfo.getScore() == Main.score) && player.getStateTimer() > 2;
    }


    /**
     * Retourne le niveau courant du joueur.
     */
    public static int getCurrentLevel() {
        return currentLevel;
    }

    /**
     * Retourne l'objet GameInfo.
     *
     * @return GameInfo
     */
    public GameInfo getGameInfo() {
        return gameInfo;
    }

    @Override
    public void resize(int width, int height) {
        gamePort.update(width, height);  // Mise à jour du viewport en fonction de la taille de l'écran
    }

    public TiledMap getMap() {
        return map;
    }

    public World getWorld() {
        return world;
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    // Libération des ressources
    public void dispose() {
        map.dispose();
        renderer.dispose();
        world.dispose();
        b2dr.dispose();
        gameInfo.dispose();
    }
}
