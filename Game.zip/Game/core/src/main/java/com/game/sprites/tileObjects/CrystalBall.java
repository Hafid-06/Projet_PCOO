package com.game.sprites.tileObjects;

import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.game.Main;
import com.game.scenes.GameInfo;
import com.game.screens.GameScreen;
import com.game.singleton.AudioManager;

/**
 * Classe représentant les boules de cristal (CrystalBall) que le joueur peut récupérer.
 */
public class CrystalBall extends InteractiveTileObject {
    private static int nbCrystalBall = 7;
    public CrystalBall(GameScreen screen, MapObject object) {
        super(screen, object);
        fixture.setUserData(this); // Associe cet objet au fixture pour détecter les collisions
        setCategoryFilter(Main.BALL_BIT); // Définit la catégorie de collision
    }


    @Override
    public void crystalBallCollect() {
        // Lorsqu'une boule de cristal est touchée, elle est récupérée.
        setCategoryFilter(Main.DESTROYED_BIT); // Change la catégorie pour éviter de futures collisions

        // Supprime toutes les cellules occupées par la crystal ball
        TiledMapTileLayer layer = (TiledMapTileLayer) map.getLayers().get(1);
        int startX = (int) (bounds.getX() / 16); // Position X de la crystal ball en tiles (mes tiles font 16 * 16 pixels)
        int startY = (int) (bounds.getY() / 16); // Position Y de la crystal ball en tiles
        int width = (int) Math.ceil(bounds.getWidth() / 16); // Largeur de la crystal ball en tiles
        int height = (int) Math.ceil(bounds.getHeight() / 16); // Hauteur de la crystal ball en tiles

        // Parcours des cellules occupées par la crystal ball
        for (int x = startX; x < startX + width; x++) {
            for (int y = startY; y < startY + height; y++) {
                TiledMapTileLayer.Cell cell = layer.getCell(x, y);
                if (cell != null) {
                    cell.setTile(null); // Supprime la cellule
                }
            }
        }

        // Mettre à jour le score et jouer le son
        GameInfo.addScore(1);
        AudioManager.getInstance().playBallSound();

        nbCrystalBall--;
        System.out.println("Vous avez récupéré une boule de cristal ! Il vous en reste " + nbCrystalBall + " à récupérer.");
    }
}
