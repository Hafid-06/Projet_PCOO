package com.game.sprites.enemies;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.utils.Array;
import com.game.Main;
import com.game.screens.GameScreen;

public class Frieza extends Enemy {

    private float stateTime;  // Temps écoulé pour les animations
    private Animation<TextureRegion> walkAnimation;  // Animation de marche de Frieza
    private Array<TextureRegion> frames;  // Frames pour l'animation de marche
    private TextureRegion deadSprite;  // Sprite pour la mort de Frieza
    private boolean isDead;  // Indique si Frieza est mort
    private boolean setToDie;  // Indique si Frieza est prêt à mourir

    /**
     * Constructeur de la classe de l'ennemie Frieza.
     * Initialise l'animation de marche, le sprite de mort, et définit les propriétés physiques.
     *
     * @param screen L'écran de jeu auquel Frieza appartient
     * @param x Position X initiale de Frieza
     * @param y Position Y initiale de Frieza
     */
    public Frieza(GameScreen screen, float x, float y) {
        super(screen, x, y);

        // Animation de marche
        frames = new Array<TextureRegion>();
        for (int i = 1; i < 2; i++) {
            frames.add(new TextureRegion(screen.getAtlas().findRegion("enemies"), i * 200, 0, 150, 115));
        }
        walkAnimation = new Animation<>(0.4f, frames); // Création de l'animation de marche avec un délai de 0.4s par frame
        stateTime = 0;

        // Sprite de mort
        deadSprite = new TextureRegion(screen.getAtlas().findRegion("enemies"), 0, 0, 163, 120);

        // Taille de l'objet
        setBounds(getX(), getY(), 50 / Main.PPM, 50 / Main.PPM);

        setToDie = false;
        isDead = false;
    }

    /**
     * Mise à jour de l'état de Frieza à chaque frame.
     * Gère l'animation de marche, la mort et la destruction physique de Frieza.
     *
     * @param dt Temps écoulé depuis la dernière mise à jour
     */
    @Override
    public void update(float dt) {
        stateTime += dt;

        // Vérifie si Frieza doit mourir
        if (setToDie && !isDead) {
            world.destroyBody(b2body);  // Détruit le corps physique de Frieza
            isDead = true;
            setRegion(deadSprite);  // Change le sprite pour le sprite de mort
            stateTime = 0;
        }
        // Sinon, met à jour la position et l'animation de marche
        else if (!isDead) {
            b2body.setLinearVelocity(velocity);  // Applique la vélocité
            setPosition(b2body.getPosition().x - getWidth() / 2, b2body.getPosition().y - getHeight() / 2);  // Met à jour la position de Frieza
            setRegion(walkAnimation.getKeyFrame(stateTime, true));  // Met à jour l'animation de marche
        }
    }

    /**
     * Définit les propriétés physiques de Frieza (corps, forme, collisions, etc.).
     */
    @Override
    protected void defineEnemy() {
        BodyDef bdef = new BodyDef();
        bdef.position.set(getX(), getY());  // Position initiale de Frieza
        bdef.type = BodyDef.BodyType.DynamicBody;
        b2body = world.createBody(bdef);  // Crée le corps physique dans le monde

        // Définition de la fixture de Frieza
        FixtureDef fdef = new FixtureDef();
        CircleShape shape = new CircleShape();
        shape.setRadius(6 / Main.PPM);  // Rayon de la forme physique de Frieza
        fdef.filter.categoryBits = Main.ENEMY_BIT;  // Définir les catégories de collision
        fdef.filter.maskBits = Main.DEFAULT_BIT | Main.OBJECT_BIT | Main.PLAYER_BIT | Main.WALL_BIT;  // Définir les masques de collision
        fdef.shape = shape;

        // Créer la fixture pour le corps de Frieza
        Fixture mainFixture = b2body.createFixture(fdef);
        mainFixture.setUserData(this);  // Associer Frieza à cette fixture
        fdef.restitution = 0.5f;  // Définir la restitution (rebond)
    }

    /**
     * Dessine Frieza à l'écran.
     *
     * @param batch Le batch utilisé pour dessiner
     */
    @Override
    public void draw(Batch batch) {
        // Si Frieza est mort, il disparaît après 15 secondes
        if (!isDead || stateTime < 15) {
            super.draw(batch);
        }
    }

    /**
     * Gère la mort de Frieza.
     * Met à jour l'état de Frieza pour qu'il meure.
     */
    @Override
    public void die() {
        setToDie = true;
        System.out.println("Vous avez tué Frieza !");  // Affiche un message dans la console
    }

    /**
     * Vérifie si Frieza est mort.
     *
     * @return true si Frieza est mort, false sinon
     */
    public boolean isDead() {
        return isDead;
    }
}
