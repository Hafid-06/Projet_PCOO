package com.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.game.Main;


public class MainMenuScreen implements Screen {

    private Main game;
    private Stage stage;
    private Texture backgroundTexture;

    /**
     * Constructeur pour initialiser l'écran du menu principal.
     * Crée la scène et les éléments UI nécessaires.
     *
     * @param game Référence au jeu principal
     */

    public MainMenuScreen(Main game) {
        this.game = game;
        stage = new Stage(new ScreenViewport());

        // Charger l'image de fond
        backgroundTexture = new Texture("images/background_main_menu.jpg");

        Gdx.input.setInputProcessor(stage);

        // Créer les éléments de l'interface utilisateur
        createUI();
    }

    private void createUI() {
        // Ajouter l'image de fond
        Image background = new Image(backgroundTexture);
        background.setSize(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        background.setFillParent(true); // Faire en sorte que l'image prenne tout l'écran
        stage.addActor(background);

        // Charger un Skin pour les boutons
        Skin skin = new Skin(Gdx.files.internal("ui/uiskin.json"));

        // Créer un tableau pour organiser les boutons
        Table table = new Table();
        table.setFillParent(true);
        stage.addActor(table);

        // Créer les boutons
        TextButton playButton = new TextButton("JOUER", skin);
        TextButton rulesButton = new TextButton("RÈGLES DU JEU", skin);
        TextButton exitButton = new TextButton("QUITTER", skin);

        // Ajouter des boutons au tableau
        table.add(playButton).pad(10).row();
        table.add(rulesButton).pad(10).row();
        table.add(exitButton).pad(10);

        // Ajouter des actions aux boutons
        playButton.addListener(new ClickListener() {
            @Override
            public void clicked(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y) {
                game.setScreen(new GameScreen(game)); // Lancer le jeu
            }
        });

        rulesButton.addListener(new ClickListener() {
            @Override
            public void clicked(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y) {
                game.setScreen(new RulesScreen(game)); // Aller à l'écran des règles
            }
        });

        exitButton.addListener(new ClickListener() {
            @Override
            public void clicked(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y) {
                Gdx.app.exit(); // Quitter le jeu
            }
        });
    }

    @Override
    public void show() {}

    @Override
    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Dessiner la scène
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        stage.dispose();
        backgroundTexture.dispose();
    }
}
