package com.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.game.screens.MainMenuScreen;
import com.game.singleton.AudioManager;

public class Main extends Game {

    // Dimensions virtuelles de la fenêtre du jeu (en pixels)
    public static final int V_WIDTH = 1500;  // Largeur virtuelle (exemple : 500 pixels)
    public static final int V_HEIGHT = 1200; // Hauteur virtuelle (exemple : 350 pixels)
    public static final float PPM = 120;   // Pixels par mètre (pour Box2D) (120 pixels par mètres)

    // SpriteBatch pour gérer les textures et sprites
    public SpriteBatch batch;

    // Bits de collision (utilisés pour identifier les différents types d'objets)
    public static final short NOTHING_BIT = 0;      // Aucun objet
    public static final short DEFAULT_BIT = 1;     // Objet par défaut
    public static final short PLAYER_BIT = 2;      // Joueur
    public static final short ENEMY_BIT = 4;       // Ennemi
    public static final short BALL_BIT = 8;       // Boule de cristal
    public static final short OBJECT_BIT = 16;     // Objets interactifs
    public static final short DESTROYED_BIT = 32; // Objets détruits
    public static final short WALL_BIT = 64;      // Murs
    public static final short LIVE = 5;           // Vie du joueur
    public static final Integer worldTimer = 300; // Temps restant dans la partie (en seconde)
    public static final Integer score = 15;       // Score de la partie qu'il faut atteindre
    public static final Integer maxLevel = 1;


    @Override
    public void create() {
        try {
            // Initialisation du SpriteBatch
            batch = new SpriteBatch();

            // Charger et afficher l'écran principal du menu
            this.setScreen(new MainMenuScreen(this));
        }
        catch (Exception e) {
            // Log l'erreur et quitte le jeu
            System.err.println("Erreur lors de l'initialisation du jeu : " + e.getMessage());
            e.printStackTrace();
            Gdx.app.exit();
        }
    }


    @Override
    public void render() {
        try {
            super.render(); // Appelle la méthode render de la classe parent
        }
        catch (Exception e) {
            // Log l'erreur et quitte le jeu
            System.err.println("Erreur lors du rendu : " + e.getMessage());
            e.printStackTrace();
            Gdx.app.exit();
        }
    }


    @Override
    public void dispose() {
        // Libère les ressources
        batch.dispose();
        AudioManager.getInstance().dispose();
    }
}
