package com.game.sprites.enemies;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.utils.Array;
import com.game.Main;
import com.game.screens.GameScreen;

public class Cell extends Enemy {

    private float stateTime;  // Temps écoulé pour l'animation
    private Animation<TextureRegion> walkAnimation;  // Animation de marche
    private Array<TextureRegion> frames;  // Frames pour l'animation de marche
    private TextureRegion deadSprite;  // Sprite de mort
    private boolean isDead;  // Indicateur de l'état de mort
    private boolean setToDie;  // Indicateur pour commencer la transition vers la mort

    /**
     * Constructeur de l'ennemie Cell.
     * Initialise les animations et définit la taille du sprite.
     *
     * @param screen La référence à l'écran de jeu
     * @param x Position x de Cell
     * @param y Position y de Cell
     */
    public Cell(GameScreen screen, float x, float y) {
        super(screen, x, y);

        // Initialisation des frames de l'animation de marche
        frames = new Array<TextureRegion>();
        for (int i = 2; i < 3; i++) {
            frames.add(new TextureRegion(screen.getAtlas().findRegion("enemies"), i * 172, 120, 133, 172));
        }
        walkAnimation = new Animation<>(0.4f, frames);  // Création de l'animation de marche avec un délai de 0.4s par frame
        stateTime = 0;

        // Initialisation du sprite de mort
        deadSprite = new TextureRegion(screen.getAtlas().findRegion("enemies"), 0, 150, 185, 120);

        // Définition de la taille du sprite
        setBounds(getX(), getY(), 50 / Main.PPM, 50 / Main.PPM);

        setToDie = false;
        isDead = false;
    }

    /**
     * Met à jour Cell.
     * Gère l'animation et la transition vers la mort si nécessaire.
     *
     * @param dt Temps écoulé depuis le dernier appel à cette méthode
     */
    @Override
    public void update(float dt) {
        stateTime += dt;  // Incrémente le temps de l'animation
        if (setToDie && !isDead) {  // Si l'ennemi est prêt à mourir
            world.destroyBody(b2body);  // Supprimer le corps physique
            isDead = true;  // Marquer comme mort
            setRegion(deadSprite);  // Afficher le sprite de mort
            stateTime = 0;  // Réinitialiser l'animation
        }
        else if (!isDead) {  // Si l'ennemi n'est pas encore mort
            b2body.setLinearVelocity(velocity);  // Appliquer la vélocité au corps
            setPosition(b2body.getPosition().x - getWidth() / 2, b2body.getPosition().y - getHeight() / 2);  // Mettre à jour la position du sprite
            setRegion(walkAnimation.getKeyFrame(stateTime, true));  // Animation de marche (boucle infinie)
        }
    }

    /**
     * Définit le corps physique de l'ennemi (Cell).
     * Cela inclut la position, le type et les fixtures physiques.
     */
    @Override
    protected void defineEnemy() {
        BodyDef bdef = new BodyDef();
        bdef.position.set(getX(), getY());  // Position initiale de l'ennemi
        bdef.type = BodyDef.BodyType.DynamicBody;  // Le corps est dynamique
        b2body = world.createBody(bdef);

        // Définir la fixture physique (le corps de Cell)
        FixtureDef fdef = new FixtureDef();
        CircleShape shape = new CircleShape();  // Forme circulaire pour le corps
        shape.setRadius(6 / Main.PPM);  // Rayon de la forme du corps
        fdef.filter.categoryBits = Main.ENEMY_BIT;  // Catégorie de collision (ennemi)
        fdef.filter.maskBits = Main.DEFAULT_BIT | Main.OBJECT_BIT | Main.PLAYER_BIT | Main.WALL_BIT;  // Masques de collision
        fdef.shape = shape;

        // Créer la fixture pour le corps de la cellule
        Fixture mainFixture = b2body.createFixture(fdef);
        mainFixture.setUserData(this);  // Lier les données utilisateur à cette fixture (référence à l'objet Cell)
        fdef.restitution = 0.5f;  // Coefficient de restitution pour les rebonds
    }

    /**
     * Dessine la cellule sur l'écran.
     * Cell est affichée tant qu'il n'est pas mort ou que l'animation n'a pas expiré.
     *
     * @param batch Le batch utilisé pour dessiner l'objet
     */
    @Override
    public void draw(Batch batch) {
        if (!isDead || stateTime < 15) {  // L'ennemi disparaît après 15 secondes de mort
            super.draw(batch);  // Appel à la méthode draw de la classe parente (Enemy)
        }
    }

    /**
     * Déclenche la mort de Cell.
     * Cell est marquée pour être détruit.
     */
    @Override
    public void die() {
        setToDie = true;  // Marquer Cell pour la destruction
        System.out.println("Vous avez tué Cell !");  // Afficher un message dans la console
    }

    /**
     * Vérifie si Cell est mort.
     *
     * @return true si Cell est mort, false sinon
     */
    public boolean isDead() {
        return isDead; // Retourne l'état de Cell
    }
}
