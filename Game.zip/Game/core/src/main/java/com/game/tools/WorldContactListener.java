package com.game.tools;

import com.badlogic.gdx.physics.box2d.*;
import com.game.Main;
import com.game.scenes.GameInfo;
import com.game.sprites.enemies.Enemy;
import com.game.sprites.tileObjects.InteractiveTileObject;
import com.game.sprites.player.Player;

public class WorldContactListener implements ContactListener {

    /**
     * Gère le début de la collision entre deux objets physiques dans le monde.
     *
     * @param contact La collision en cours
     */
    @Override
    public void beginContact(Contact contact) {
        Fixture fixA = contact.getFixtureA();
        Fixture fixB = contact.getFixtureB();

        // Vérification si le joueur entre en contact avec une boule de cristal (InteractiveTileObject)
        if (isPlayerAndBall(fixA, fixB)) {
            handlePlayerBallCollision(fixA, fixB);
        }

        // Vérification si un Enemy entre en contact avec un mur
        if (isEnemyAndWall(fixA, fixB)) {
            handleEnemyWallCollision(fixA, fixB);
        }

        // Vérification si le joueur est en collision avec un ennemi (Frieza ou Cell) et si le joueur est en attaque
        if (isPlayerAndEnemy(fixA, fixB)) {
            handlePlayerEnemyCollision(fixA, fixB);
        }
    }


    /**
     * Vérifie si le contact concerne un joueur et une boule de cristal.
     *
     * @param fixA Le premier fixture
     * @param fixB Le deuxième fixture
     * @return True si le contact concerne un joueur et une boule
     */
    private boolean isPlayerAndBall(Fixture fixA, Fixture fixB) {
        return (fixA.getUserData() instanceof Player && fixB.getUserData() instanceof InteractiveTileObject) ||
            (fixB.getUserData() instanceof Player && fixA.getUserData() instanceof InteractiveTileObject);
    }

    /**
     * Gère la collision entre un joueur et une boule de cristal (le joueur récupère la boule).
     *
     * @param fixA Le premier fixture
     * @param fixB Le deuxième fixture
     */
    private void handlePlayerBallCollision(Fixture fixA, Fixture fixB) {
        Player player = (fixA.getUserData() instanceof Player) ? (Player) fixA.getUserData() : (Player) fixB.getUserData();
        InteractiveTileObject ball = (fixA.getUserData() instanceof InteractiveTileObject) ?
            (InteractiveTileObject) fixA.getUserData() :
            (InteractiveTileObject) fixB.getUserData();

        ball.crystalBallCollect();  // Le joueur collecte la boule de cristal
    }

    /**
     * Vérifie si Frieza ou Cell (Enemy) entre en collision avec un mur.
     *
     * @param fixA Le premier fixture
     * @param fixB Le deuxième fixture
     * @return True si Frieza touche un mur
     */
    private boolean isEnemyAndWall(Fixture fixA, Fixture fixB) {
        return fixA.getFilterData().categoryBits == Main.WALL_BIT || fixB.getFilterData().categoryBits == Main.WALL_BIT;
    }

    /**
     * Gère la collision entre Frieza et Cell et un mur (inverse la direction de Frieza et Cell).
     *
     * @param fixA Le premier fixture
     * @param fixB Le deuxième fixture
     */
    private void handleEnemyWallCollision(Fixture fixA, Fixture fixB) {
        if (fixA.getFilterData().categoryBits == Main.WALL_BIT) {
            if (fixB.getUserData() instanceof Enemy) {
                ((Enemy) fixB.getUserData()).reverseVelocity(true, false);
            }
        }
        else if (fixB.getFilterData().categoryBits == Main.WALL_BIT) {
            if (fixA.getUserData() instanceof Enemy) {
                ((Enemy) fixA.getUserData()).reverseVelocity(true, false);
            }
        }
    }

    /**
     * Vérifie si le joueur est en collision avec un ennemi.
     *
     * @param fixA Le premier fixture
     * @param fixB Le deuxième fixture
     * @return True si le contact concerne un joueur et un ennemi
     */
    private boolean isPlayerAndEnemy(Fixture fixA, Fixture fixB) {
        return (fixA.getUserData() instanceof Player && fixB.getUserData() instanceof Enemy) ||
            (fixB.getUserData() instanceof Player && fixA.getUserData() instanceof Enemy);
    }

    /**
     * Gère la collision entre un joueur et un ennemi (Frieza et Cell).
     * Si le joueur est en attaque, l'ennemi meurt.
     *
     * @param fixA Le premier fixture
     * @param fixB Le deuxième fixture
     */
    private void handlePlayerEnemyCollision(Fixture fixA, Fixture fixB) {
        Player player = (fixA.getUserData() instanceof Player) ? (Player) fixA.getUserData() : (Player) fixB.getUserData();
        Enemy enemy = (fixA.getUserData() instanceof Enemy) ? (Enemy) fixA.getUserData() : (Enemy) fixB.getUserData();

        // Si le joueur est en mode attaque, l'ennemi meurt et on augmente le score
        if (player.isAttacking()) {
            enemy.die();
            GameInfo.addScore(1);
        }
        else {
            player.loseLife();  // Le joueur perd une vie
        }
    }

    @Override
    public void endContact(Contact contact) {
    }

    @Override
    public void preSolve(Contact contact, Manifold oldManifold) {
    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {
    }
}
