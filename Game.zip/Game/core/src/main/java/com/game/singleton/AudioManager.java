package com.game.singleton;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;

public class AudioManager {
    private static AudioManager instance;

    // Exemple de ressources audio
    private Sound attackSound;
    private Music backgroundMusic;
    private Sound ballSound;

    // Constructeur privé pour empêcher l'instanciation directe
    private AudioManager() {
        loadAudio(); // Charger les ressources audio
    }

    // Méthode pour obtenir l'instance unique
    public static AudioManager getInstance() {
        if (instance == null) {
            instance = new AudioManager();
        }
        return instance;
    }

    // Charger les ressources audio
    private void loadAudio() {
        attackSound = Gdx.audio.newSound(Gdx.files.internal("audio/sounds/attack.wav"));
        backgroundMusic = Gdx.audio.newMusic(Gdx.files.internal("audio/music/game_music.ogg"));
        ballSound = Gdx.audio.newSound(Gdx.files.internal("audio/sounds/ball.wav"));
    }

    // Jouer un effet sonore
    public void playAttackSound() {
        attackSound.play();
    }

    public Sound getAttackSound() {
        return attackSound;
    }

    public void playBallSound() {
        ballSound.play();
    }

    public Sound getBallSound() {
        return ballSound;
    }

    // Jouer de la musique en boucle
    public void playBackgroundMusic() {
        backgroundMusic.setLooping(true);
        backgroundMusic.play();
        backgroundMusic.setVolume(0.2f);
    }

    public Music getBackgroundMusic() {
        return backgroundMusic;
    }

    // Libère les ressources
    public void dispose() {
        if (backgroundMusic != null) backgroundMusic.dispose();
        if (attackSound != null) attackSound.dispose();
        if (ballSound != null) ballSound.dispose();
    }

}
