package com.game.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.game.Main;

public class GameWonScreen implements Screen {

    private Viewport viewport;  // Vue du jeu
    private Stage stage;  // Stage pour afficher les éléments UI
    private Game game;  // Référence au jeu principal

    /**
     * Constructeur pour initialiser l'écran de victoire.
     * Crée la scène et les éléments UI nécessaires.
     *
     * @param game Référence au jeu principal
     */
    public GameWonScreen(Game game) {
        this.game = game;

        // Initialisation de la vue et de la scène
        viewport = new FitViewport(Main.V_WIDTH, Main.V_HEIGHT, new OrthographicCamera());
        stage = new Stage(viewport, ((Main) game).batch);

        // Définition du style de police
        Label.LabelStyle font = new Label.LabelStyle(new BitmapFont(), Color.WHITE);

        // Création de la table qui va contenir les éléments UI
        Table table = new Table();
        table.center();  // Centrer les éléments
        table.setFillParent(true);  // Remplir l'écran avec la table

        // Création des labels pour le texte affiché à l'écran
        Label gameOverLabel = new Label("YOU WON !", font);
        gameOverLabel.getStyle().font.getData().setScale(2);
        Label playAgainLabel = new Label("Press Enter to Play Again", font);
        playAgainLabel.getStyle().font.getData().setScale(2);

        // Ajout des labels dans la table
        table.add(gameOverLabel).expandX();  // Label de victoire
        table.row();  // Passage à la ligne suivante
        table.add(playAgainLabel).expandX().padTop(10f);  // Label pour rejouer

        // Ajout de la table au stage
        stage.addActor(table);
    }

    @Override
    public void show() {
    }

    /**
     * Rendu de l'écran de victoire.
     * Si l'écran est touché, on retourne à l'écran de jeu.
     *
     * @param v Delta du temps écoulé depuis le dernier rendu.
     */
    @Override
    public void render(float v) {
        // Si l'utilisateur touche l'écran, on redémarre le jeu
        if (Gdx.input.isKeyPressed(Input.Keys.ENTER)) {
            game.setScreen(new GameScreen((Main) game));  // Changement d'écran
            dispose();  // Libération des ressources de l'écran actuel
        }

        // Nettoyage de l'écran avec un fond noir
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Dessiner la scène
        stage.draw();
    }

    @Override
    public void resize(int i, int i1) {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    /**
     * Libération des ressources de l'écran.
     */
    @Override
    public void dispose() {
        stage.dispose();  // Libération du stage
    }
}
