package com.game.sprites.enemies;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.World;
import com.game.screens.GameScreen;

public abstract class Enemy extends Sprite {

    protected World world;  // Le monde physique dans lequel l'ennemi évolue
    protected GameScreen screen;  // L'écran de jeu auquel l'ennemi appartient
    public Body b2body;  // Le corps physique de l'ennemi
    public Vector2 velocity;  // La vélocité de l'ennemi (déplacement dans l'espace)

    /**
     * Constructeur de la classe Enemy.
     * Initialise l'ennemi dans le monde physique avec sa position et sa vélocité.
     *
     * @param screen L'écran de jeu auquel l'ennemi appartient
     * @param x Position X initiale de l'ennemi
     * @param y Position Y initiale de l'ennemi
     */
    public Enemy(GameScreen screen, float x, float y) {
        this.world = screen.getWorld();  // Récupère le monde physique depuis l'écran
        this.screen = screen;  // L'écran de jeu
        setPosition(x, y);  // Définit la position de l'ennemi
        defineEnemy();  // Appel à la méthode qui définira les propriétés physiques de l'ennemi
        velocity = new Vector2(-1, -2);  // Vélocité de l'ennemi (vitesse initiale)
        b2body.setActive(true);  // Active le corps physique au départ
    }

    /**
     * Méthode abstraite à implémenter par les classes filles.
     * Définir les propriétés physiques de l'ennemi (forme, collision, etc.).
     */
    protected abstract void defineEnemy();

    /**
     * Méthode abstraite à implémenter par les classes filles.
     * Permet de gérer l'état de mort de l'ennemi.
     */
    public abstract void die();

    /**
     * Méthode abstraite à implémenter par les classes filles.
     * Met à jour l'ennemi à chaque frame.
     *
     * @param dt Temps écoulé depuis la dernière mise à jour
     */
    public abstract void update(float dt);

    /**
     * Inverse la vélocité de l'ennemi sur un ou plusieurs axes.
     *
     * @param x Indique si la vélocité sur l'axe X doit être inversée
     * @param y Indique si la vélocité sur l'axe Y doit être inversée
     */
    public void reverseVelocity(boolean x, boolean y) {
        if (x) velocity.x = -velocity.x;  // Inverser la vitesse sur l'axe X
        if (y) velocity.y = -velocity.y;  // Inverser la vitesse sur l'axe Y
    }
}
